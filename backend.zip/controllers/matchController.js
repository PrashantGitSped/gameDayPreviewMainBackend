const Match = require('../models/Match');

exports.createMatch = async (req,res)=>{
    try{
        //console.log(req.body)
        //res.send("inside createm match");

        const match = new Match(req.body)
        await match.save();
        res.status(201).json(match)



    }catch(error){
        res.status(400).json({message: error.message})
    }
}

exports.getMatchOutcomePrediction = async (req,res) => {
    try{
        //console.log(req.params.id)
        res.send('iinside getmatchoutcome prediction')
        /*
        const match = await Match.findById(req.params.id);
        if(!match){
            return res.status(404).json({message: 'Match not found'});
        }
        const prediction = "Team A is likely to win";
        res.json({match, prediction})
         */
    }catch(error){
        res.status(500).json({message:error.message})
    }
};