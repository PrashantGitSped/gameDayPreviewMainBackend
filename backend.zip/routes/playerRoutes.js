const express = require('express')
const router = express.Router()
const {createPlayer, getPlayerPerformance} = require('../controllers/playerController')
const authMiddleware = require('../middleware/authMiddleware')


router.post('/players', authMiddleware, createPlayer)
router.get('/players/:id/performance', authMiddleware, getPlayerPerformance)

module.exports = router