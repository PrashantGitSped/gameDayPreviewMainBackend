const express = require('express')
const router = express.Router()
const {createMatch, getMatchOutcomePrediction} = require('../controllers/matchController')
const authMiddleware = require('../middleware/authMiddleware')

router.post('/matches', authMiddleware, createMatch)
router.get('/matches/:id/prediction',authMiddleware, getMatchOutcomePrediction)

module.exports = router